"""API module for JobPulse"""
