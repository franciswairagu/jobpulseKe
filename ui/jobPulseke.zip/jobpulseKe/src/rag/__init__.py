"""RAG module for JobPulse"""
