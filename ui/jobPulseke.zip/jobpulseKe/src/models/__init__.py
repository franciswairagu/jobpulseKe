"""Models module for JobPulse"""
